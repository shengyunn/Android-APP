package com.example.web;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.pm.ActivityInfo;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private TextView wifiNameText;
    private EditText urlInput;
    private Button openWebButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 全螢幕模式
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);


        // 初始化元件
        wifiNameText = findViewById(R.id.wifiNameText);
        urlInput = findViewById(R.id.urlInput);
        openWebButton = findViewById(R.id.openWebButton);

        // 請求定位權限
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            displayWifiName();  // 如果已經有權限，顯示 Wi-Fi 名稱
        }

        // 按鈕點擊事件，打開網頁
        openWebButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urlInput.getText().toString();
                if (!url.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                    intent.putExtra("url", url);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "請輸入網址", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // 顯示 Wi-Fi 名稱
    private void displayWifiName() {
        String wifiName = getCurrentWifiName();
        Log.d("WiFiName", "Current Wi-Fi: " + wifiName);
        wifiNameText.setText("Wi-Fi Name: " + wifiName);
    }

    // 獲取當前的 Wi-Fi 名稱
    private String getCurrentWifiName() {
        WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        String ssid = wifiInfo.getSSID();

        // 如果 SSID 以引號包圍，去除引號
        if (ssid != null && ssid.startsWith("\"") && ssid.endsWith("\"")) {
            ssid = ssid.substring(1, ssid.length() - 1);
        }

        return ssid != null ? ssid : "<unknown ssid>";
    }

    // 處理運行時許可權結果
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                displayWifiName();  // 如果權限授予，顯示 Wi-Fi 名稱
            } else {
                Toast.makeText(this, "權限被拒絕，無法顯示 Wi-Fi 名稱", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
