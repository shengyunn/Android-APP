package com.example.web;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.content.pm.ActivityInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class WebViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 全螢幕沉浸式模式
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setContentView(R.layout.activity_webview);

        // 強制設定為橫向模式
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        // 使用已有的 WebView 元件
        WebView webView = findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();

        // 啟用 JavaScript 和其他重要設置
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(true); // 允許訪問檔案
        webSettings.setDomStorageEnabled(true); // 啟用 DOM 儲存
        webSettings.setMediaPlaybackRequiresUserGesture(false); // 允許自動播放媒體
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); // 允許混合內容 (HTTP + HTTPS)

        // 設定 WebViewClient 以防跳轉到外部瀏覽器
        webView.setWebViewClient(new WebViewClient());

        // 獲取從 MainActivity 傳遞來的 URL
        String url = getIntent().getStringExtra("url");
        if (url != null && !url.isEmpty()) {
            webView.loadUrl(url);
        } else {
            webView.loadData("Invalid URL", "text/html", "UTF-8");
        }
    }

}
